import React from "react";
import {inject, observer} from "mobx-react";
import ReactTable from 'react-table';
import './Rt.css';

const columns = [
	{
		name: 'Time',
		selector: 'ts',
		sortable: true,
	},
	{
		name: 'Product',
		selector: 'product',
		sortable: true,
	},
	{
		name: 'Amount',
		selector: 'notional',
		sortable: true,
	},
	{
		name: 'Currency',
		selector: 'currency',
		sortable: true,
	},
	{
		name: 'Instruments',
		selector: 'notional',
		sortable: true,
	},
	{
		name: 'Trade Date',
		selector: 'tradeDate',
		sortable: true,
	}
];

const Row = ({index, style}) => (
	<div className={index % 2 ? "ListItemOdd" : "ListItemEven"} style={style}>
		Row {index}
	</div>
);

@inject('store')
@observer
class T1 extends React.Component {
	render() {
		let data = this.props.store.data.toJS();
		return (
			<div className="w-full h-full">
				<ReactTable
					data={data}
					columns={columns}/>
			</div>
		);
	}
}

export default T1;
