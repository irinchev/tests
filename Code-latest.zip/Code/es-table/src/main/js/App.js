import React from "react";
import {inject, observer} from "mobx-react";
import AgTable from "./AgTable";

@inject('store')
@observer
class App extends React.Component {
	render() {
		return (
			<div className="w-full h-full flex flex-col p-8">
				<div className="flex-1 flex pb-4">
					<button
						onClick={e => this.props.store.fetch(0)}
						className="block uppercase shadow bg-indigo-800 hover:bg-indigo-700 focus:shadow-outline focus:outline-none text-white text-xs py-3 px-10 rounded">
						Get
					</button>
				</div>
				<AgTable/>
			</div>
		);
	}
}

export default App;
