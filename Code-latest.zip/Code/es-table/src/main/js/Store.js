import {observable, runInAction} from "mobx";
import axios from "axios";
import autobind from "autobind-decorator";

export default class Store {

	data = observable.map({
		numberOfRecordsTotal: 0,
		numberOfRecordsSlice: 0,
		sliceStartIndex: 0,
		products: []
	}, {deep: false});

	@autobind
	fetch(startIndex) {
		axios.get("/api/fetch", {
			params: {sliceStartIndex: startIndex || 0}
		})
			.then((response) => {
				if (response && response.status === 200 && response.data) {
					runInAction(() => {
						this.data.replace(response.data);
					});
				} else {
					console.log(response)
					this.data.replace({
						numberOfRecordsTotal: 0,
						numberOfRecordsSlice: 0,
						sliceStartIndex: 0,
						products: []
					});
				}
			})
			.catch((error) => {
				console.log(error);
				this.data.replace({
					numberOfRecordsTotal: 0,
					numberOfRecordsSlice: 0,
					sliceStartIndex: 0,
					products: []
				});
			})
			.finally({});
	}
}
