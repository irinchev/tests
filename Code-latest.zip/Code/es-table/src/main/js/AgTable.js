import React from 'react';
import {inject, observer} from "mobx-react";
import {AgGridReact} from 'ag-grid-react';
import {AllCommunityModules} from "ag-grid-community";
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import autobind from "autobind-decorator";
import {autorun, observable, runInAction, toJS} from "mobx";
import axios from "axios";

const columns = [
	{
		headerName: "Time", field: "ts"
	},
	{
		headerName: "Product", field: "product"
	},
	{
		headerName: "Amount", field: "notional"
	},
	{
		headerName: "Currency", field: "currency"
	},
	{
		headerName: "Instruments", field: "instruments",
		cellRenderer: (data) => {
			if (data && data.value) {
				return "<div>" + data.value.map(u => "<span class='pr-1'>" + u.ticker + "</span>") + "</div>";
			} else {
				return "";
			}
		}
	},
	{
		headerName: "Trade Date", field: "tradeDate"
	}
];

class DS {
	constructor(data, fetch) {
		this.data = data;
		this.fetch = fetch;
	}

	getRows(params) {
		console.log(this.data.sliceStartIndex)
		if (this.data.numberOfRecordsSlice > 0) {
			let lastSliceIndex = this.data.sliceStartIndex + this.data.numberOfRecordsSlice;
			if (params.startRow >= this.data.sliceStartIndex && params.endRow <= lastSliceIndex) {
				let rowsThisPage = this.data.products.slice(
					params.startRow - this.data.sliceStartIndex,
					params.endRow - this.data.sliceStartIndex
				);
				params.successCallback(
					rowsThisPage,
					this.data.numberOfRecordsTotal
				);
			} else {
				if (this.fetch) {
					this.fetch(params.startRow);
				}
			}
		}
	}
}

class DataSource {

	constructor() {
		this.data = {
			numberOfRecordsTotal: 0,
			numberOfRecordsSlice: 0,
			sliceStartIndex: 0,
			products: []
		};
	}

	getRows(params) {
		let lastSliceIndex = this.data.sliceStartIndex + this.data.numberOfRecordsSlice;
		if (this.data.numberOfRecordsSlice > 0 && params.startRow >= this.data.sliceStartIndex && params.endRow <= lastSliceIndex) {
			let rowsThisPage = this.data.products.slice(
				params.startRow - this.data.sliceStartIndex,
				params.endRow - this.data.sliceStartIndex
			);
			params.successCallback(
				rowsThisPage,
				this.data.numberOfRecordsTotal
			);
		} else {
			let result = axios.get("/api/fetch", {
				params: {sliceStartIndex: params.startRow || 0}
			});
			result.then(response => {
				if (response && response.status === 200 && response.data) {
					this.data = response.data;
					let rowsThisPage = this.data.products.slice(
						params.startRow - this.data.sliceStartIndex,
						params.endRow - this.data.sliceStartIndex
					);
					params.successCallback(
						rowsThisPage,
						this.data.numberOfRecordsTotal
					);
				} else {
					this.data = {
						numberOfRecordsTotal: 0,
						numberOfRecordsSlice: 0,
						sliceStartIndex: 0,
						products: []
					};
				}
			});
		}
	}

	@autobind
	page(startRow, endRow) {
		let lastSliceIndex = this.data.sliceStartIndex + this.data.numberOfRecordsSlice;
		if (startRow >= this.data.sliceStartIndex && endRow <= lastSliceIndex) {
			let rowsThisPage = this.data.products.slice(
				startRow - this.data.sliceStartIndex,
				endRow - this.data.sliceStartIndex
			);
		}
	}
}

@inject('store')
@observer
class AgTable extends React.Component {

	componentDidMount999() {
		this.disposer = autorun(() => {
			let data = toJS(this.props.store.data);
			if (this.gridApi) {
				this.gridApi.setDatasource(
					new DS(data, this.props.store.fetch)
				);
			}
			if (this.gridApi) {
				this.gridApi.setDatasource(
					new DS(data, this.props.store.fetch)
				);
			}
		});
	}

	componentWillUnmount888() {
		if (this.disposer) {
			this.disposer();
		}
	}

	@autobind
	onGridReady(params) {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;
		this.gridApi.setDatasource(
			//new DS(data, this.props.store.fetch)
			new DataSource()
		);
	}

	render() {
		return (
			<div className="ag-theme-balham w-full h-full">
				<AgGridReact
					modules={AllCommunityModules}
					columnDefs={columns}
					pagination={true}
					onGridReady={this.onGridReady}
					deltaRowDataMode={true}
					rowBuffer={0}
					rowModelType="infinite"
					getRowNodeId={data => data.id}>
				</AgGridReact>
			</div>
		);
	}
}

export default AgTable;
