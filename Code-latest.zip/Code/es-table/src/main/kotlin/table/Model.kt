package table

import java.math.BigDecimal
import java.time.LocalDateTime
import java.time.ZonedDateTime

data class Product(
        val id: String,
        val ts: ZonedDateTime,
        val product: String,
        val notional: BigDecimal,
        val currency: String,
        val instruments: List<Instrument>,
        val tradeDate: ZonedDateTime,
        val redemptionDate: ZonedDateTime
)

data class Instrument(
        val ticker: String,
        val isin: String
)
