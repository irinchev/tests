package table

import com.fasterxml.jackson.module.kotlin.KotlinModule
import org.apache.http.HttpHost
import org.elasticsearch.client.RestClient
import org.elasticsearch.client.RestHighLevelClient
import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer
import org.springframework.boot.builder.SpringApplicationBuilder
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer
import org.springframework.context.annotation.Bean
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.RequestMapping

@SpringBootApplication
class TableApp : SpringBootServletInitializer() {
    override fun configure(builder: SpringApplicationBuilder): SpringApplicationBuilder {
        return builder.sources(TableApp::class.java)
    }
}

fun main(args: Array<String>) {
    SpringApplication.run(TableApp::class.java, *args)
}

@Controller
class IndexController {
    @RequestMapping("/", "/home")
    fun index(): String {
        return "index.html"
    }
}

@Bean
fun jackson2ObjectMapperBuilderCustomizer(): Jackson2ObjectMapperBuilderCustomizer {
    return Jackson2ObjectMapperBuilderCustomizer { jacksonObjectMapperBuilder ->
        jacksonObjectMapperBuilder.modulesToInstall(KotlinModule())
    }
}

@Bean(destroyMethod = "close")
fun restHighLevelClient() = RestHighLevelClient(
        RestClient.builder(HttpHost("localhost", 9200, "http"))
)
