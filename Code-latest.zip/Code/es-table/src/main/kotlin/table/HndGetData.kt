package table

import com.fasterxml.jackson.databind.ObjectMapper
import org.elasticsearch.action.search.SearchRequest
import org.elasticsearch.client.RequestOptions
import org.elasticsearch.client.RestHighLevelClient
import org.elasticsearch.common.unit.TimeValue.timeValueMinutes
import org.elasticsearch.script.ScriptType
import org.elasticsearch.script.mustache.SearchTemplateRequest
import org.elasticsearch.search.SearchHit
import org.elasticsearch.search.builder.SearchSourceBuilder
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam
import java.math.BigDecimal
import java.text.SimpleDateFormat

@Controller
class HndGetData {

    val log = LoggerFactory.getLogger(HndGetData::class.java)
    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")

    @Autowired
    lateinit var restHighLevelClient: RestHighLevelClient

    @Autowired
    lateinit var objectMapper: ObjectMapper

    @GetMapping("/api/fetch")
    fun fetch(@RequestParam("sliceStartIndex") startIndex: Int): ResponseEntity<*> {
        log.info("Search offset $startIndex")
        val request = SearchRequest("sp-products")
        val builder = SearchSourceBuilder().size(500).sort("ts").searchAfter(arrayOf(startIndex))
        request.source(builder)
        //request.scroll(timeValueMinutes(1L))
        val response = restHighLevelClient.search(request, RequestOptions.DEFAULT)
        log.info("Total number of records found ${response.hits.totalHits}")
        log.info("Slice number of records found ${response.hits.hits.size}")
        val scrollId = response.scrollId

        val products = response.hits.hits.mapNotNull { toProduct(it.sourceAsString) }
        return ResponseEntity.ok(
                Response(
                        response.hits.totalHits,
                        products.size,
                        startIndex,
                        products
                )
        )
    }

//    fun fetchBySearch(@RequestParam("sliceStartIndex") startIndex: Int): ResponseEntity<*> {
//        log.info("Search offset $startIndex")
//        val request = SearchRequest("sp-products")
//    }

    fun toProduct(src: String): Product? {
        try {
            return objectMapper.readValue(src, Product::class.java)
        } catch (e: Exception) {
            log.warn("Cannot parse $src", e)
            return null
        }
    }

    companion object {
        data class Response(
                val numberOfRecordsTotal: Long,
                val numberOfRecordsSlice: Int,
                val sliceStartIndex: Int,
                val products: List<Product>
        )
    }
}
