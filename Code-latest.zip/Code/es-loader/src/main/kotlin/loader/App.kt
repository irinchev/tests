package loader

import com.fasterxml.jackson.databind.ObjectMapper
import org.apache.http.HttpHost
import org.elasticsearch.action.bulk.BulkRequest
import org.elasticsearch.action.index.IndexRequest
import org.elasticsearch.client.RequestOptions
import org.elasticsearch.client.RestClient
import org.elasticsearch.client.RestHighLevelClient
import org.elasticsearch.client.indices.CreateIndexRequest
import org.elasticsearch.common.xcontent.XContentType
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.CommandLineRunner
import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.context.annotation.Bean
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.random.Random
import kotlin.system.exitProcess

@SpringBootApplication
class App : CommandLineRunner {

    val log = LoggerFactory.getLogger(App::class.java)
    val sdf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")

    @Autowired
    lateinit var restHighLevelClient: RestHighLevelClient

    override fun run(vararg args: String?) {
        var objectMapper = ObjectMapper()
        log.info("[ESL] Start ${LocalDateTime.now()}")
        //restHighLevelClient.indices().create(CreateIndexRequest("sp-products"), RequestOptions.DEFAULT)
        val bulkRequest = BulkRequest()
        generate().forEach {
            bulkRequest
                    .add(IndexRequest("sp-products", "product", it.id)
                            .source(objectMapper.writeValueAsString(it), XContentType.JSON))
        }
        restHighLevelClient.bulk(bulkRequest, RequestOptions.DEFAULT)
        log.info("[ESL] End ${LocalDateTime.now()}")
        exitProcess(0)
    }

    fun generate(): List<Product> {
        return (1..50000).map { i ->
            Product(
                    System.nanoTime().toString() + "-" + UUID.randomUUID().toString(),
                    ZonedDateTime.now(ZoneOffset.UTC).format(sdf),
                    products.random(),
                    notional.random(),
                    currencies.random(),
                    (1..Random.nextInt(1, 4)).map {
                        Instrument(
                                (1..4).map { source.random() }.joinToString(""),
                                (1..3).map { source.random() }.joinToString("")
                        )
                    },
                    ZonedDateTime.now(ZoneOffset.UTC).format(sdf),
                    ZonedDateTime.now(ZoneOffset.UTC).plusMonths(6).format(sdf)
            )
        }
    }
}

fun main(args: Array<String>) {
    SpringApplication.run(App::class.java, *args)
}

@Bean(destroyMethod = "close")
fun restHighLevelClient() = RestHighLevelClient(
        RestClient.builder(HttpHost("localhost", 9200, "http"))
)

data class Product(
        val id: String,
        val ts: String,
        val product: String,
        val notional: BigDecimal,
        val currency: String,
        val instruments: List<Instrument>,
        val tradeDate: String,
        val redemptionDate: String
)

data class Instrument(
        val ticker: String,
        val isin: String
)

val source = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
val products = listOf("ELN", "BRC", "FCN")
val currencies = listOf("CHF", "USD", "GBP")
val notional = listOf(BigDecimal("50000"), BigDecimal("100000"), BigDecimal("250000"))
