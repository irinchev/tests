import React from "react";
import Navigation from "./Navigation";
import Table from "./Table";
import {
    RSocketClient,
    JsonSerializer,
    IdentitySerializer
} from "rsocket-core";
import RSocketWebSocketClient from "rsocket-websocket-client";

export default class App extends React.Component {

    componentDidMount() {
        const client = new RSocketClient({
            serializers: {
                data: JsonSerializer,
                metadata: IdentitySerializer
            },
            setup: {
                keepAlive: 60000,
                lifetime: 180000,
                dataMimeType: 'application/json',
                metadataMimeType: 'message/x.rsocket.routing.v0',
            },
            transport: new RSocketWebSocketClient({
                url: 'ws://localhost:8081/ws'
            }),
        });
        console.log(client)
        client.connect().subscribe({
            onComplete: socket => {
                console.log(socket)
                socket.requestStream({
                    data: {
                        'someParameter': "someValue"
                    },
                    metadata: String.fromCharCode('blotter.events'.length) + 'blotter.events',
                }).subscribe({
                    onComplete: () => console.log('complete'),
                    onError: error => {
                        console.log(error);
                    },
                    onNext: payload => {
                        console.log(payload.data);
                    },
                    onSubscribe: subscription => {
                        subscription.request(2147483647);
                    },
                });
            },
            onError: error => {
                console.log("got connection error");
                console.error(error);
            },
            onSubscribe: cancel => {
                /* call cancel() to abort */
                console.log(cancel)
            },
            onNext: value => {
                console.log(value.data);
            },
        });
    }

    render() {
        return (
            <div className="w-full h-full">
                <Navigation/>
                <Table columns={columns} data={[]}/>
            </div>
        );
    }
}

const columns = [
    {
        Header: 'Id',
        accessor: 'id',
    },
    {
        Header: 'Time',
        accessor: 'timeStamp',
    },
    {
        Header: 'Message',
        accessor: 'message',
    }
];