package blotter

import java.time.LocalDateTime

data class BlotterEvent(
        val id: String,
        val timeStamp: LocalDateTime,
        val message: String
)