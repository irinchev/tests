package blotter.config

import blotter.streaming.EventProducer
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.scheduling.annotation.EnableScheduling

@Configuration
@EnableScheduling
class Data {
    @Bean
    fun eventProducer(): EventProducer {
        return EventProducer()
    }
}