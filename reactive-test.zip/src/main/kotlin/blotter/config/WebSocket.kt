package blotter.config
//
//import blotter.streaming.EventProducer
//import blotter.streaming.EventStreamingHandler
//import com.fasterxml.jackson.databind.ObjectMapper
//import org.springframework.beans.factory.annotation.Autowired
//import org.springframework.context.annotation.Bean
//import org.springframework.context.annotation.Configuration
//import org.springframework.web.reactive.HandlerMapping
//import org.springframework.web.reactive.handler.SimpleUrlHandlerMapping
//import org.springframework.web.reactive.socket.WebSocketHandler
//import org.springframework.web.reactive.socket.server.support.WebSocketHandlerAdapter
//
////@Configuration
//class WebSocket {
//
//    @Autowired
//    lateinit var objectMapper: ObjectMapper
//
//    @Autowired
//    lateinit var eventProducer: EventProducer
//
//    @Bean
//    fun eventStreamingHandler() : EventStreamingHandler {
//        return EventStreamingHandler(objectMapper, eventProducer)
//    }
//
//    @Bean
//    fun webSocketHandlerAdapter(): WebSocketHandlerAdapter {
//        return WebSocketHandlerAdapter()
//    }
//
//    @Bean
//    fun handlerMapping(): HandlerMapping? {
//        val map: MutableMap<String, WebSocketHandler?> = HashMap()
//        map["/ws"] = eventStreamingHandler()
//        val simpleUrlHandlerMapping = SimpleUrlHandlerMapping()
//        simpleUrlHandlerMapping.order = 10
//        simpleUrlHandlerMapping.urlMap = map
//        return simpleUrlHandlerMapping
//    }
//}