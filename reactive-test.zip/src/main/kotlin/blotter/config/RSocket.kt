package blotter.config

import org.springframework.context.annotation.Configuration

@Configuration
class RSocket  {

}