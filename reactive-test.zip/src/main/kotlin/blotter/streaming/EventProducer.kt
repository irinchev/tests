package blotter.streaming

import blotter.BlotterEvent
import org.slf4j.LoggerFactory.getLogger
import org.springframework.scheduling.annotation.Scheduled
import reactor.core.publisher.DirectProcessor
import reactor.core.publisher.Flux
import java.time.LocalDateTime
import java.util.*

class EventProducer {

    private val log = getLogger(EventProducer::class.java)
    private val processor = DirectProcessor.create<BlotterEvent>()

    fun subscribe(): Flux<BlotterEvent> {
        return processor
    }

    @Scheduled(fixedRate = 2000L)
    fun emit() {
        val message = "[" + System.currentTimeMillis() + "]"
        //log.info(message)
        processor.onNext(
                BlotterEvent(
                        UUID.randomUUID().toString(),
                        LocalDateTime.now(),
                        message
                )
        )
    }
}