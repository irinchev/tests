package blotter.streaming

//
//class EventStreamingHandler(
//        private val objectMapper: ObjectMapper,
//        private val eventProducer: EventProducer) : WebSocketHandler {
//
//    override fun handle(session: WebSocketSession): Mono<Void> {
//        return session.send(
//                eventProducer.subscribe()
//                        .map(objectMapper::writeValueAsString)
//                        .map(session::textMessage)
//        )
//    }
//
//}