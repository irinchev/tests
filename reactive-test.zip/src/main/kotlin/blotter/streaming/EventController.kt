package blotter.streaming

import blotter.BlotterEvent
import org.slf4j.LoggerFactory
import org.springframework.messaging.handler.annotation.MessageMapping
import org.springframework.stereotype.Controller
import reactor.core.publisher.Flux

@Controller
class EventController(private val eventProducer: EventProducer) {

    private val log = LoggerFactory.getLogger(EventController::class.java)

    @MessageMapping("blotter.events")
    fun onEvent(): Flux<BlotterEvent> {
        log.info("New subscription")
        return eventProducer.subscribe()
    }

}