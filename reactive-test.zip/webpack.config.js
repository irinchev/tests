const path = require("path");
const {WebpackPluginServe: Serve} = require('webpack-plugin-serve');
const outputPath = path.resolve('./build');

const options = {
    static: [outputPath, path.resolve('./src/main/resources/static')],
    host: "localhost",
    progress: "minimal",
    port: 5555,
    liveReload: true,
    log: { level: 'trace' },
    middleware: (app, builtins) => {
        app.use(builtins.proxy('/ws', {
            target: 'http://localhost:8081',
            ws: true,
            pathRewrite: {
                '/ws': ''
            }
        }))
    }
}
module.exports = {
    entry: [
        "./src/main/js/index.js",
        'webpack-plugin-serve/client'
    ],
    output: {
        path: outputPath,
        filename: "bundle.js"
    },
    resolve: {
        extensions: [".js"],
    },
    mode: "development",
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: /node_modules/,
                use: ["babel-loader"]
            },
            {
                test: /\.css$/,
                use: ["style-loader", "css-loader"]
            }
        ]
    },
    plugins: [
        new Serve(options)
    ],
    watch: true
}