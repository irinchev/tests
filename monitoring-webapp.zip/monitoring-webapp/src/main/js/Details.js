import React from "react";

export default class Details extends React.Component {
	render() {
		return (
			<div className="flex-1 w-full h-full p-8">
				<div className="bg-gray-100 w-full h-full flex items-center justify-center">
					<span className="text-4xl font-black text-gray-400">No row selected</span>
				</div>
			</div>
		);
	}
}
