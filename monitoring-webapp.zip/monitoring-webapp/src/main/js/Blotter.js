import React from "react";
import {AgGridReact} from "ag-grid-react";
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import autobind from "autobind-decorator";
import {inject, observer} from "mobx-react";
import {autorun, toJS} from "mobx";

const columns = [
	{
		headerName: 'Time',
		field: 'ts'
	},
	{
		headerName: 'Service',
		field: 'service'
	},
	{
		headerName: 'Progress',
		field: 'events',
		cellRendererFramework: EventsCellRenderer
	},
	{
		headerName: 'Duration',
		field: 'duration'
	},
];

function EventsCellRenderer(p) {
	let events = p.value;
	let markup = [];
	let en = 0;
	events.forEach(e => {
		switch(e.payloadType.toLowerCase()) {
			case "request": markup.push(<span key={"events-req-" + p.data.correlationId} className="p-1 round bg-green-100">REQ</span>); break;
			case "response": markup.push(<span key={"events-res-" + p.data.correlationId} className="p-1 round bg-indigo-100">RES</span>); break;
			default: markup.push(<span key={"events-evt-" + p.data.correlationId} className="p-1 round bg-gray-100">{++en}</span>); break;
		}
	});
	return (
		<div>{markup}</div>
	);
}

@inject("store")
@observer
export default class Blotter extends React.Component {

	componentDidMount() {
		this.dispose = autorun(() => {
			let event = toJS(this.props.store.currentEvent);
			if (event && event.correlationId && this.api) {
				let node = this.api.getRowNode(event.correlationId);
				if (node) {
					let events = node.data.events.concat(event);
					node.setDataValue("events", events);
				} else {
					let newRowData = {
						correlationId: event.correlationId,
						service: event.service,
						events: [event]
					};
					this.api.updateRowData({add: [newRowData], addIndex: 0});
				}
			}
		});
	}

	componentWillUnmount() {
		this.dispose();
	}

	@autobind
	onGridReady(e) {
		this.api = e.api;
		this.columnApi = e.columnApi;
		this.api.sizeColumnsToFit();
	}

	render() {
		let data = [];
		return (
			<div className="w-full h-full p-8 ag-theme-balham">
				<AgGridReact
					columnDefs={columns}
					deltaRowDataMode={true}
					paginationAutoPageSize={true}
					rowData={[]}
					pagination={true}
					getRowNodeId={data => data.correlationId}
					onGridReady={this.onGridReady}/>
			</div>
		);
	}
}
