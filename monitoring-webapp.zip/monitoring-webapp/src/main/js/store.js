import {action, observable} from "mobx";
import ReconnectingWebSocket from 'reconnecting-websocket';

export default class Store {

	constructor() {
		this.socket = new ReconnectingWebSocket(location.origin.replace(/^http/, 'ws') + "/ws", [], {
			connectionTimeout: 3000
		});
		this.socket.addEventListener('message', this.onRawEvent);
	}

	@action.bound
	onRawEvent(m) {
		if (m && m.data) {
			let raw = m.data;
			try {
				let dataItem = JSON.parse(raw);
				let cid = dataItem["correlationId"];
				if (cid) {
					// if (this.eventMap.has(cid)) {
					// 	let existing = this.eventMap.get(cid);
					// 	this.eventMap.set(cid, {correlationId: cid, events: existing.events.concat(dataItem)});
					// } else {
					// 	this.eventMap.set(cid, {correlationId: cid, events: [dataItem]});
					// }
					this.currentEvent = dataItem;
				}
				//console.log(this.eventMap.get(cid));
			} catch (e) {
				console.warn(e);
			}
		}
	}
	@observable
	currentEvent = undefined;

	@observable
	eventMap = observable.map({}, {deep: false});

}
