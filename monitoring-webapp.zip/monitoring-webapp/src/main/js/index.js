import React from "react";
import {render} from "react-dom";
import {Provider} from "mobx-react";
import Store from "./store";
import App from "./App";

const store = new Store();

render(
<Provider store={store}>
	<App/>
	</Provider>,
document.getElementById("app")
);
