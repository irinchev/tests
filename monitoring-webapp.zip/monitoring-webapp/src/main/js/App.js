import React from "react";
import Blotter from "./Blotter";
import Details from "./Details";

export default class App extends React.Component {
	render() {
		return(
			<div className="w-full h-full flex">
				<div className="w-1/2 h-full">
					<Blotter/>
				</div>
				<div className="flex-1 h-full">
					<Details/>
				</div>
			</div>
		);
	}
}
