package monitoring

import com.fasterxml.jackson.module.kotlin.KotlinModule
import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer
import org.springframework.boot.builder.SpringApplicationBuilder
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer
import org.springframework.context.annotation.Bean
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.RequestMapping

@SpringBootApplication
class WebApp : SpringBootServletInitializer() {
    override fun configure(builder: SpringApplicationBuilder): SpringApplicationBuilder {
        return builder.sources(WebApp::class.java)
    }
}

fun main(args: Array<String>) {
    SpringApplication.run(WebApp::class.java, *args)
}

@Controller
class IndexController {
    @RequestMapping("/", "/home")
    fun index(): String {
        return "index.html"
    }
}

@Bean
fun jackson2ObjectMapperBuilderCustomizer(): Jackson2ObjectMapperBuilderCustomizer {
    return Jackson2ObjectMapperBuilderCustomizer { jacksonObjectMapperBuilder ->
        jacksonObjectMapperBuilder.modulesToInstall(KotlinModule())
    }
}
