package monitoring

import com.fasterxml.jackson.databind.ObjectMapper
import org.slf4j.LoggerFactory
import org.springframework.scheduling.annotation.Scheduled
import org.springframework.web.socket.CloseStatus
import org.springframework.web.socket.TextMessage
import org.springframework.web.socket.WebSocketSession
import org.springframework.web.socket.handler.TextWebSocketHandler
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.*
import java.util.concurrent.CompletableFuture.runAsync
import java.util.concurrent.ConcurrentHashMap

class EventHandler(val objectMapper: ObjectMapper) : TextWebSocketHandler() {

    private val fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private val log = LoggerFactory.getLogger(EventHandler::class.java)
    private val sessions = ConcurrentHashMap<String, WebSocketSession>()
    private val events = ConcurrentHashMap<String, MutableList<Event>>()

    fun onRawEvent(e: RawEvent) {
        log.info("[RAW] $e")
        val cidGroup = events.getOrDefault(e.correlationId, mutableListOf())
        val event = Event(
                e.correlationId,
                e.callId,
                e.callerId,
                e.service,
                e.serviceVersion,
                e.timeStamp,
                e.payloadType,
                e.payload,
                e.host,
                true
        )
        cidGroup.add(event)
        val message = TextMessage(objectMapper.writeValueAsString(event))
        for ((cid, session) in sessions) {
            runAsync {
                try {
                    if (session.isOpen) {
                        session.sendMessage(message)
                    }
                } catch (e: Exception) {
                    log.warn("$e")
                }
            }
        }
    }

    override
    fun afterConnectionClosed(session: WebSocketSession, status: CloseStatus) {
        log.info("[CLS] Connection closed for session $session")
        sessions.remove(session.id)
        super.afterConnectionClosed(session, status)
    }

    override
    fun afterConnectionEstablished(session: WebSocketSession) {
        log.info("[OPN] Connection opened from ${session.remoteAddress}")
        sessions[session.id] = session
        super.afterConnectionEstablished(session)
    }

    val cids = ConcurrentHashMap<String, MutableList<RawEvent>>()
    @Scheduled(fixedRate = 500L)
    fun generateEvent() {
        if (cids.size < 3) {
            cids[UUID.randomUUID().toString()] = mutableListOf()
        }
        val group = cids.entries.random()
        val type = when (group.value.size) {
            0 -> "request"
            1 -> "market-data"
            else -> "response"
        }
        val e = RawEvent(
                group.key,
                UUID.randomUUID().toString(),
                UUID.randomUUID().toString(),
                "spark/search",
                "0.1",
                ZonedDateTime.now(ZoneOffset.UTC).format(fmt),
                type,
                "{}",
                "localhost"
        )
        group.value.add(e)
        onRawEvent(e)
        if(group.value.size > 2) {
            cids.remove(group.key)
        }
    }

    companion object {
        data class Event(
                val correlationId: String,
                val callId: String,
                val callerId: String,
                val service: String,
                val serviceVersion: String,
                val timeStamp: String,
                val payloadType: String,
                val payload: String,
                val host: String,
                val isFirstEvent: Boolean
        )

        data class RawEvent(
                val correlationId: String,
                val callId: String,
                val callerId: String,
                val service: String,
                val serviceVersion: String,
                val timeStamp: String,
                val payloadType: String,
                val payload: String,
                val host: String
        )
    }
}
